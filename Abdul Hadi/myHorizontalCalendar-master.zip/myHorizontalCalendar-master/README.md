# myHorizontalCalendar
useful samIn this horizontal scrolling calendar, I have used recyclerView, which is perhaps one of the most powerful Containers present in Android SDK. It is very flexible and extensible. Although it's quite complex to use.ples for reuse
Here are the features it supports.
a) It shows Sundays in Red Color for easy identification.
b) You can customize it for the number of days, presently it is for 30 days, starting at 2 days before today.
c) It has two ImageViews to control the horizontal scrolling on left and right.
d) In this example I am are using Calendar data, but you alter it to use any other data by modifying MyCalendar and MyCalendar java files.
read this ariticle to know more https://medium.com/@atanudasgupta2014/creating-a-horizontal-scrolling-calendar-using-android-sdk-95914288b8c3?source=friends_link&sk=7eacb25c07b43e9ef042f0e2543dfbf4
